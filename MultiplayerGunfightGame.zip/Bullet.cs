
using UnityEngine;
using Mirror;

public class Bullet : NetworkBehaviour
{
    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            // Example damage handling
            Destroy(collision.gameObject);
        }

        Destroy(gameObject);
    }
}
